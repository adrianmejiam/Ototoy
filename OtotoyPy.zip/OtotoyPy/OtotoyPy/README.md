## Overview
**OtotoyPy** is a tool for automating downloads from Ototoy using their api.
There is currently no documentation for the api therefore it may be wiser to scrape the html for additional tagging information.

It is worth mentioning this project is still incomplete.

Tested on **[Python 3.8.0](https://www.python.org/downloads/release/python-380/)**


**Installation:**
- Install requirements
```
pip install -r requirements.txt
```

## Command Usage
```
python main.py {command_name} {value}
```
Command  | Description  | Example
------------- | ------------- | -------------
-u | Provide url of Ototoy album for download| `python main.py -u "https://ototoy.jp/_/default/p/36666"`
-f| Format selection (Currently has no use since the only supported format is FLAC) | `python main.py -u "https://ototoy.jp/_/default/p/36666" -f "flac"`

## Finding Cookies

- Log in
- Navigate to an album page.
- Inspect element (F12 on Chrome)
- Visit the Network tab.
- Refresh the webpage if the Network tab is empty.
- Click on the first document requested which will usually be an album ID such as 555121
- Copy the Cookie and save to config.py

![Example](https://i.imgur.com/L522JzX.png)

## Config.json

- Currently some config should remain unchanged as this is still an incomplete project.

**credentials:**

Config  | Description  | Example
------------- | ------------- | -------------
Cookie | Ototoy Cookies | Apache=xxx; udidbv=xxx; PHPSESSID=xxx; xxx; app_token=xxx

**directories:**

Config  | Description  | Example
------------- | ------------- | -------------
log_directory | Directory to save log files to | `Z:/OtotoyPy/Logs`
downloads | Directory to save downloads to  | `Z:/OtotoyPy/Downloads`
artist_folders | Whether or not to nest downloads into artist folders | `True/False`


**files:**

Config  | Description  | Example
------------- | ------------- | -------------
audio_quality  | Format to download by default | `flac` `aac` `alac` `wav`
fallback_audio_quality | Format to falback on in the case that Ototoy does not have the default format | `flac` `aac` `alac` `wav`
cover_name | Name of album cover downloaded | `cover.jpg`


## Disclaimer
- The usage of this script **may be** illegal in your country. It's your own responsibility to inform yourself of Copyright Law.
