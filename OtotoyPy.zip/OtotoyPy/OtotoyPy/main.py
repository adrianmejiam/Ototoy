# First-party
import os
import re
import argparse
from datetime import datetime
import logging
import platform
import sys
import time
# Third-party
from tqdm import tqdm
from mutagen.flac import FLAC, Picture
import mutagen.id3 as id3
from mutagen.id3 import ID3NoHeaderError
# OtotoyPy
import api
# Get arguments
def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', nargs="*", help="URL.", required=True)
    parser.add_argument('-f', help="Format. (flac, mp3)", required=False)
    return parser.parse_args()
# Set up our logging tools
def log_setup():
    # Generate filename
    filename = '{:%H_%M_%S}.log'.format(datetime.now())
    # Create subfolder based on today's date
    folder_name = os.path.join(cfg['directories']['log_directory'], '{:%Y-%m-%d}'.format(datetime.now()))
    make_dir(folder_name)
    # Set path of the log file
    log_path = os.path.join(folder_name, filename)
    # Set up logging to file
    logging.basicConfig(level=logging.DEBUG,
                        handlers=[logging.FileHandler(log_path, 'w', 'utf-8')],
                        format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S')
    # Define a Handler which writes INFO messages or higher to the sys.stderr
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    # Set a format which is simpler for console use
    formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
    # Tell the handler to use this format
    console.setFormatter(formatter)
    # Add the previously defined handler to the root logger
    logging.getLogger().addHandler(console)
    ## Next we'll define some other loggers.
    # This gives us more control over logging certain areas of the script
    logger = logging.getLogger("Ototoy")
    logger.setLevel(logging.INFO)
    return logger
# Match the url and grab the id of the artist/album etc
def match_url(url):
    # Expression taken and edited from QoDL-Reborn
    return re.match(r'https?://ototoy\.jp/_/default/(?:(?:p|a)/|\w+(?:-\w+))(\w+)', url).group(1)
# Identify the url type
def get_type(url):
    type = url.split('/')[5]
    if not type in ['p', 'a']:
        type = url.split('/')[4]
    return type
# Create directory after checking existence
def make_dir(dir):
    if not os.path.isdir(dir):
        os.makedirs(dir)
# Check platform, this could determine how we handle some operations
def is_win():
    if platform.system() == 'Windows':
        return True
# Sanitize strings, required to create filenames with invalid characters
def sanitize(string):
    if is_win():
        return re.sub(r'[\/:*?"><|]', '_', string)
    else:
        return re.sub('/', '_', string)
# Check for existence of a filepath
def exist_check(path):
	if os.path.isfile(path):
		logging.info(("{} already exists locally.".format(os.path.basename(path))))
		return True
# Download album cover
def download_cover(jacket_path, ap):
    cp = os.path.join(ap, cfg['files']['cover_name'])
    if exist_check(cp):
        pass
    else:
        try:
            url = "https://imgs.ototoy.jp/imgs/jacket/{}".format(jacket_path.replace(".jpg", "orig.jpg"))
            r = client.session.get(url)
            if r.status_code == 404:
                logger.warning("Jacket not found")
                cp = False
                return cp
            else:
                r.raise_for_status()
                with open (cp, 'wb') as f:
                    f.write(r.content)
                return cp
        except AttributeError:
            logger.warning("Jacket not found")
            cp = False
            return cp
# Decide which format to download
def format_decision(permitted_format):
    # Split permitted formats and append to list
    format_list = permitted_format.split(",")
    logging.debug("Available formats: {}".format(format_list))
    if args.f == None:
        selected_format = cfg['files']['audio_quality']
        if selected_format not in format_list:
            logger.warning("{} not available. Falling back to {}.".format(selected_format, cfg['files']['fallback_audio_quality']))
            selected_format = cfg['files']['fallback_audio_quality']
    else:
        selected_format = args.f
    logging.debug("{} has been decided".format(selected_format))
    return selected_format
# Download track
def download_track(track, ap):
    selected_format = format_decision(permitted_format=track['permitted_format'])
    url = "http://api.ototoy.jp/app/track/{}.{}".format(track['code'], selected_format)
    headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36",
    "Connection": "close",
    "Cookie": cfg['credentials']['cookie']
    }
    r = client.session.get(url, stream=True, headers=headers)
    ## Returning a JSON indicates the file is still being prepared
    # This means we need to request again
    while r.headers['Content-Type'] == 'application/json':
        logger.info("{} is still being prepared. Retrying..".format(track['code']))
        # Sleeping gives Ototoy time to prepare the file
        time.sleep(3)
        r = client.session.get(url, stream=True, headers=headers)
        # Break only if content type has changed to audio
        if r.headers['Content-Type'] != 'application/json':
            logger.info("{} has been prepared.".format(track['code']))
            break
    # Get content size
    size = int(r.headers.get('content-length', 0))
    # Assign temporary filename for writing to
    pre = os.path.join(ap, track['track_num'] + ".OtotoyPy")
    # Permanent filename assigned when download is complete
    post = (os.path.join(ap, sanitize("{}. {}.{}".format(track['track_num'], track['title'], selected_format))))
    # Check if file already exists
    if exist_check(post):
        pass
    else:
        logger.info("Downloading {}".format(os.path.basename(post)))
        with open(pre, 'wb') as f:
            with tqdm(total=size, unit='B',
                unit_scale=True, desc=os.path.basename(post), unit_divisor=1024,
                initial=0, miniters=1) as bar:
                    for chunk in r.iter_content(32*1024):
                        if chunk:
                            f.write(chunk)
                            bar.update(len(chunk))
        try:
            # Rename and sanitize our temporary filename
            os.rename(pre, post)
        except OSError:
            logging.debug("Failed to rename downloaded file")
        return post
# Organize our track metadata
def organize_meta(track):
    meta = {
            "ALBUM": track['ptitle'],
            "ALBUMARTIST": track['aname'],
            "ARTIST": track['aname'],
            "TITLE": track['title'],
            "DISCNUMBER": track['disc_num'],
            "TRACKNUMBER": track['track_num'],
            "COMMENT": track['code']
    }
    # Correction for discnumber/tracknumbers
    if meta['DISCNUMBER'] == None:
        meta['DISCNUMBER'] = "1"
    if meta['TRACKNUMBER'] == None:
        meta['TRACKNUMBER'] = "1"
    return meta
# Function which will tag our files
def tag(track, file_path, cover_path):
    meta = organize_meta(track=track)
    if str(file_path).endswith('.flac'):
        # Embed coverart before tags
        if cover_path != False:
            f_file = FLAC(file_path)
            f_image = Picture()
            f_image.type = 3
            if str(cover_path).endswith('png'):
                mime = 'image/png'
            else:
                mime = 'image/jpeg'
            f_image.desc = 'Front Cover'
            with open(cover_path, 'rb') as f:
                f_image.data = f.read()
            f_file.add_picture(f_image)
            f_file.save()
        # Add tags to the flac file
        f = FLAC(file_path)
        logging.info("Writing tags to {}".format(os.path.basename(file_path)))
        for k, v in meta.items():
            f[k] = str(v)
        f.save()
    if str(file_path).endswith('.mp3'):
        legend={
            "ALBUM": id3.TALB,
            "ALBUMARTIST": id3.TPE2,
            "ARTIST": id3.TPE1,
            "COMMENT": id3.COMM,
            "COMPOSER": id3.TCOM,
            "COPYRIGHT": id3.TCOP,
            "DATE": id3.TDRC,
            "GENRE": id3.TCON,
            "ISRC": id3.TSRC,
            "LABEL": id3.TPUB,
            "PERFORMER": id3.TOPE,
            "TITLE": id3.TIT2
        }
        # Confirm the header
        try:
            audio = id3.ID3(file_path)
        except ID3NoHeaderError:
            audio = id3.ID3()
        logging.info("Writing tags to {}".format(os.path.basename(file_path)))
        for k, v in meta.items():
            try:
                id3tag = legend[k]
                audio[id3tag.__name__] = id3tag(encoding=3, text=v)
            except KeyError:
                pass
        # Embed album cover
        if cover_path != False:
            with open(cover_path, 'rb') as cov_obj:
                audio.add(id3.APIC(3, 'image/jpg', 3, '', cov_obj.read()))
            # Save audio marking end of MP3 tagging process
            audio.save(file_path, 'v2_version=3')
    # Tag M4A files.
    if str(file_path).endswith('.m4a'):
        logging.critical("M4A is not currently supported. Exiting..")
        sys.exit()
# Function to handle tracks to save duplicating code in main()
def tracks_handler(tracks):
    # Log tracks and give the user feedback of track total
    logger.info("{} tracks found".format(tracks['count']))
    logging.debug(tracks)
    # Start the track loop
    for track in tracks['tracks']:
        # Assign directory names
        ap_basename = sanitize("{} - {}".format(track['aname'], track['ptitle']))
        # If artist folders enabled nest in artist name subfolder, else don't.
        if cfg['directories']['artist_folders']:
            ap = os.path.join(cfg['directories']['downloads'], sanitize(track['aname']), ap_basename)
        else:
            ap = os.path.join(cfg['directories']['downloads'], ap_basename)
        # Create directory
        make_dir(ap)
        # Check for existence of the album cover before deciding to download again.
        cp = os.path.join(ap, cfg['files']['cover_name'])
        if not os.path.exists(cp):
            # Download cover
            cp = download_cover(jacket_path=track['jacket_path'], ap=ap)
        post = download_track(track=track, ap=ap)
        tag(track=track, file_path=post, cover_path=cp)
    logging.info("Downloaded all tracks.")
# Main function which will organize our ripping process
def main():
    for url in args.u:
        # Determine url type and get the id of the artist page/album page
        id = match_url(url)
        type = get_type(url)
        if type == "a":
            ### We don't request each album individually.
            ## api stores all tracks for an artist in a dict so we can use this instead for less requests
            tracks = client.get_meta(type_one="tracks", type_two="in_artist", id=id)
            tracks_handler(tracks)
            sys.exit()
        elif type == "p":
            # Get tracks in album
            tracks = client.get_meta(type_one="tracks", type_two="in_album", id=id)
            tracks_handler(tracks)
        else:
            logger.critical("Type found not supported: {}".format(type))
            sys.exit()
# Set some global variables and run our main function
if __name__ == "__main__":
    args = get_args()
    cfg = api.config.cfg
    logger = log_setup()
    client = api.Client()
    main()
